// Funktion zur Berechnung des Abholdatums
function berechneAbholdatum(prioritaet) {
    const startdatum = new Date(); // aktuelles Datum
    let zusatzTage = 0;

    if (prioritaet === "Tief") {
        zusatzTage = 5;
    } else if (prioritaet === "Standard") {
        zusatzTage = 0;
    } else if (prioritaet === "Express") {
        zusatzTage = -2;
    }

    const abholDatum = new Date(startdatum);
    abholDatum.setDate(abholDatum.getDate() + zusatzTage + 7); // 7 Basistage + Priorität

    return abholDatum.toLocaleDateString("de-DE");
}

// Abholdatum anzeigen
function zeigeAbholdatum() {
    const prioritaet = document.getElementById('priority-select').value;
    const abholDatum = berechneAbholdatum(prioritaet);
    document.getElementById('abholdatum-output').textContent
}