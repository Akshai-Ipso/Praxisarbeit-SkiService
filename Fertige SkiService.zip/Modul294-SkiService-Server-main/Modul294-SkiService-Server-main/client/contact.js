function berechneAbholdatum(prioritaet) {
    const startdatum = new Date(); // Aktuelles Datum
    let zusatzTage = 0;

    switch (prioritaet) {
        case "Express":
            zusatzTage = -2;
            break;
        case "Standard":
            zusatzTage = 0;
            break;
        case "Tief":
            zusatzTage = 5;
            break;
        default:
            return null; // Gibt null zurück, wenn die Priorität nicht korrekt ist
    }

    const abholDatum = new Date(startdatum);
    abholDatum.setDate(abholDatum.getDate() + zusatzTage + 7); // 7 Basistage + Priorität

    return abholDatum.toISOString().split("T")[0]; // ISO-Format: yyyy-mm-dd
}



// Live-Vorschau aktualisieren
function aktualisiereVorschau() {
    const nameElement = document.getElementById("name");
    const emailElement = document.getElementById("email");
    const telefonElement = document.getElementById("telefon");
    const prioritaetElement = document.getElementById("prioritaet");
    const serviceElement = document.getElementById("service");

    if (!nameElement || !emailElement || !telefonElement || !prioritaetElement || !serviceElement) {
        console.error("Ein oder mehrere Formularelemente fehlen im DOM! Überprüfen Sie die IDs der Elemente.");
        return;
    }

    const name = nameElement.value || "Nicht angegeben";
    const email = emailElement.value || "Nicht angegeben";
    const telefon = telefonElement.value || "Nicht angegeben";
    const prioritaet = prioritaetElement.value || "Nicht ausgewählt";
    const service = serviceElement.value || "Nicht ausgewählt";
    let abholdatum = "Nicht berechnet";

    if (prioritaet) {
        abholdatum = berechneAbholdatum(prioritaet);
    }

    const vorschau = document.getElementById("preview");
    if (vorschau) {
        vorschau.classList.remove("d-none");
        vorschau.innerHTML = `
            <h5>Vorschau Ihrer Eingaben:</h5>
            <p><strong>Kundenname:</strong> ${name}</p>
            <p><strong>E-Mail:</strong> ${email}</p>
            <p><strong>Telefon:</strong> ${telefon}</p>
            <p><strong>Priorität:</strong> ${prioritaet}</p>
            <p><strong>Dienstleistung:</strong> ${service}</p>
            <p><strong>Abholdatum:</strong> ${abholdatum}</p>
        `;
    } else {
        console.error("Das Vorschau-Element fehlt im DOM!");
    }
}

// Event Listener für das Service-Formular
document.addEventListener("DOMContentLoaded", () => {
    const serviceForm = document.getElementById("service-form");
    if (serviceForm) {
        serviceForm.addEventListener("submit", async function (event) {
            event.preventDefault(); // Standardaktion verhindern

            if (!serviceForm.checkValidity()) {
                serviceForm.classList.add("was-validated");
                return;
            }

            // Hole die Formulardaten
            const nameElement = document.getElementById("name");
            const emailElement = document.getElementById("email");
            const telefonElement = document.getElementById("telefon");
            const prioritaetElement = document.getElementById("prioritaet");
            const serviceElement = document.getElementById("service");
            const messageElement = document.getElementById("message");

            if (!nameElement || !emailElement || !telefonElement || !prioritaetElement || !serviceElement || !messageElement) {
                console.error("Ein oder mehrere Formularelemente fehlen im DOM! Stellen Sie sicher, dass alle IDs korrekt sind.");
                return;
            }

            const name = nameElement.value;
            const email = emailElement.value;
            const telefon = telefonElement.value;
            const prioritaet = prioritaetElement.value;
            const service = serviceElement.value;
            const message = messageElement.value;

            // Berechne das Abholdatum basierend auf der Priorität
            const berechneAbholdatum = (prioritaet) => {
                const startdatum = new Date();
                let zusatzTage = 0;

                switch (prioritaet) {
                    case "Express":
                        zusatzTage = -2;
                        break;
                    case "Standard":
                        zusatzTage = 0;
                        break;
                    case "Tief":
                        zusatzTage = 5;
                        break;
                    default:
                        return null;
                }

                const abholDatum = new Date(startdatum);
                abholDatum.setDate(abholDatum.getDate() + zusatzTage + 7); // 7 Basistage + Priorität
                return abholDatum.toISOString().split("T")[0];
            };

            const abholdatum = berechneAbholdatum(prioritaet);

            if (!abholdatum) {
                alert("Abholdatum konnte nicht berechnet werden. Überprüfen Sie die Priorität.");
                return;
            }

            // Erstelle das Payload-Objekt
            const payload = {
                name,
                email,
                telefon,
                prioritaet,
                service,
                message,
                erfassungsdatum: new Date().toISOString().split("T")[0],
                abholdatum,
            };

            try {
                const response = await fetch("http://localhost:5000/api/registration", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(payload),
                });

                if (response.ok) {
                    // Speichere alle relevanten Daten in `sessionStorage`
                    sessionStorage.setItem("registrationData", JSON.stringify(payload));

                    // Weiterleitung auf die Erfolgsseite
                    window.location.href = "success.html";
                } else {
                    alert("Fehler bei der Anmeldung. Bitte versuchen Sie es erneut.");
                }
            } catch (error) {
                console.error("Fehler:", error);
                alert("Es ist ein Fehler aufgetreten. Bitte versuchen Sie es später erneut.");
            }
        });
    }
});




// Event Listener für das Kontaktformular
document.addEventListener("DOMContentLoaded", () => {
    const contactForm = document.getElementById("contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", async function (event) {
            event.preventDefault(); // Standardaktion verhindern

            if (!contactForm.checkValidity()) {
                contactForm.classList.add("was-validated");
                return;
            }

            const name = document.getElementById("contact-name").value;
            const email = document.getElementById("contact-email").value;
            const message = document.getElementById("contact-message").value;

            const payload = {
                name,
                email,
                message,
            };

            console.log("Kontaktformular-Daten:", payload);

            try {
                alert("Ihre Nachricht wurde erfolgreich gesendet!");
                contactForm.reset();
                contactForm.classList.remove("was-validated");
            } catch (error) {
                alert("Es ist ein Fehler aufgetreten. Bitte versuchen Sie es später erneut.");
                console.error("Fehler:", error);
            }
        });
    } else {
        console.error("Kontakt-Formular fehlt im DOM!");
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const formElements = document.querySelectorAll("#service-form input, #service-form select, #service-form textarea");
    const livePreview = {
        name: document.getElementById("preview-name"),
        email: document.getElementById("preview-email"),
        telefon: document.getElementById("preview-telefon"),
        prioritaet: document.getElementById("preview-prioritaet"),
        service: document.getElementById("preview-service"),
        message: document.getElementById("preview-message")
    };

    formElements.forEach((element) => {
        element.addEventListener("input", () => {
            const value = element.value || "Nicht angegeben";
            const previewElement = livePreview[element.id];
            if (previewElement) {
                previewElement.textContent = value;
            }
        });
    });
});

document.addEventListener("DOMContentLoaded", () => {
    const registrationData = JSON.parse(sessionStorage.getItem("registrationData"));

    if (registrationData) {
        document.getElementById("name").innerText = registrationData.name || "Nicht verfügbar";
        document.getElementById("pickup_date").innerText = registrationData.pickup_date || "Nicht verfügbar";
        document.getElementById("service").innerText = registrationData.service || "Nicht verfügbar";
        document.getElementById("priority").innerText = registrationData.priority || "Nicht verfügbar";
    } else {
        console.error("Keine Registrierungsdaten gefunden!");
    }
});
