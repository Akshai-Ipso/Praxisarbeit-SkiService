# Install Ski-Service Server (Backend), Praxisarbeit

## Voraussetzungen

- Node.js muss installiert sein
  
## Setup / Installation

Achtung: Der nachfolgende Installationsbefehl muss zwingend aus dem Projektverzeichnis des Node.js Servers (./server) gestartet werden.
`C:\skiservice-server\server`

- `npm install`

## Start

- Achtung: Nicht in einem Onedrive Ordner starten!

- `npm start`
- `npm run dev`

Happy Coding 😊
