
const registrationmodel = {
    id:"",
    name:"",
    email:"",
    phone:"",
    priority:"",
    service:"",
};

module.exports = {
    registrationmodel:registrationmodel
  };